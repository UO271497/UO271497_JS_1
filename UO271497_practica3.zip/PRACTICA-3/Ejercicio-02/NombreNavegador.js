
document.write(infoNavegador.nombre);
