infoNavegador = new Object();
infoNavegador.nombre = navigator.appName;
infoNavegador.idioma = navigator.language;
infoNavegador.version = navigator.appVersion;
infoNavegador.plataforma = navigator.platform;
infoNavegador.vendedor = navigator.vendor;
infoNavegador.agente = navigator.userAgent;
infoNavegador.javaActivo = navigator.javaEnabled();
infoNavegador.plugins = navigator.plugins.length;
infoNavegador.appCodeName = navigator.appCodeName;
infoNavegador.onLine = navigator.onLine;
infoNavegador.cookie = navigator.cookieEnabled;
infoNavegador.geolocalizacion=navigator.geolocation;
infoNavegador.product = navigator.product;
infoNavegador.pdfViewer=navigator.pdfViewerEnabled;
infoNavegador.webDriver=navigator.webdriver;

