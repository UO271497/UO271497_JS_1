document.write("<h4>");
document.write(aux.universidad);
document.write("</h4>");