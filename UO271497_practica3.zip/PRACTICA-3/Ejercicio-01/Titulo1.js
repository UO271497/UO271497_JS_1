document.write("<h1>");
document.write(aux.nombre);
document.write("</h1>");