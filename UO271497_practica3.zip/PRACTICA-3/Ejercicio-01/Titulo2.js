document.write("<h2>");
document.write(aux.titulacion);
document.write("</h2>");