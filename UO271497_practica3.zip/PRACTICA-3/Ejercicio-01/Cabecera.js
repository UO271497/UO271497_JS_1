var aux = new Object();
aux.nombre = "Software y estándares en la Web";
aux.titulacion = "Grado en Ingeniería Informática del Software";
aux.centro = "Escuela de Ingeniería Informática";
aux.universidad = "Universidad de Oviedo";
aux.curso = "2022-23";
aux.estudiante = "Miguel Suárez Artime";
aux.email = "UO271497@uniovi.es";