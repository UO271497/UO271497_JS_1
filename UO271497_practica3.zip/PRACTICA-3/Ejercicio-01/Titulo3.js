document.write("<h3>");
document.write(aux.centro);
document.write("</h3>");