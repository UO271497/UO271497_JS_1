document.write("<p>Curso actual: ");
document.write(aux.curso);
document.write("</p>");
document.write("<p>Estudiante: ");
document.write(aux.estudiante);
document.write("</p>");
document.write("<p>e-mail: ");
document.write(aux.email);
document.write("</p>");
